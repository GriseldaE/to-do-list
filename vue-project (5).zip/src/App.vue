<script setup>
import { ref, computed } from "vue";

const tareas = ref([]);
const counter = ref(0);
var msg ="";
const add = () => {


    tareas.value.push(msg);
    counter.value++;
    msg ="";
    


};
const delet = (index) => {
var removed = tareas.value.splice(index, 1);
for (var i = 0; i < counter.value; i++) {
  tareas[i]= removed[i];
}
counter.value--;

    
};

</script>

<template>
  <h1>Ejercicio 03</h1>
  <h2>Total de tareas {{counter}}</h2>
  <input v-model="msg">
   <button @click="add">Add</button>

   <h2 class="mt-3">Mis Tareas</h2>
        <ul class="list-group mt-2">
            <li
                class="list-group-item"
                v-for="(item, index) in tareas"
                :key="index"

                
            >
                {{ item }} 
            <button @click= "delet(index)">Eliminar </button> </li> 
        </ul>

        
</template>